INSERT INTO favorites (userid, name)
VALUES(:userid, :name)