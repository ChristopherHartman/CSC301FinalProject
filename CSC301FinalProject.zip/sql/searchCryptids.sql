SELECT *
FROM cryptids
WHERE name LIKE :name