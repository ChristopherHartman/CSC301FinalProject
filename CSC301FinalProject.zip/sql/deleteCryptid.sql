DELETE FROM cryptids
WHERE name = :name