INSERT INTO cryptids (name, description)
VALUES(:name, :description)