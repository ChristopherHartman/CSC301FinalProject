SELECT *
FROM cryptids
WHERE name like :name;