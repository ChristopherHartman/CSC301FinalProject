SELECT *
FROM cryptids