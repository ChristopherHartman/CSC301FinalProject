SELECT *
FROM USERS
WHERE name like :name;