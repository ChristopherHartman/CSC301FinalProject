UPDATE cryptids
SET name = :name, description = :description
WHERE name = :name