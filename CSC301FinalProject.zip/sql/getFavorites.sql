SELECT *
FROM FAVORITES
WHERE userid like :userid;