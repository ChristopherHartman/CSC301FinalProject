DELETE FROM favorites
WHERE favoritesid = :favoritesid